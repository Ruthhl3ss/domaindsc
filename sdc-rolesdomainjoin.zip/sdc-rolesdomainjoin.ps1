<#PSScriptInfo
.Version 0.1
Score Utica SDC Domain Controller Install roles and join domain
#>

#Requires -Module ActiveDirectoryDsc
#Requires -Module ComputerManagementDsc

<#
    .DESCRIPTION
        This configuration will create a new domain with a new forest and a forest
        functional level of Server 2016.
#>
Configuration sdcrolesdomainjoin {

  param
  (
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [System.Management.Automation.PSCredential]
    $Credential,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $DomainName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $ComputerName
  )

  $Name = ($DomainName -split '\.')[0]

  Import-DscResource -ModuleName PSDesiredStateConfiguration
  Import-DscResource -ModuleName ActiveDirectoryDsc
  Import-DscResource -ModuleName ComputerManagementDsc

  node 'localhost'
  {
    WindowsFeature InstallADDS
    {
      Name   = 'AD-Domain-Services'
      Ensure = 'Present'
    }

    WindowsFeature InstallDNS
    {
      Ensure = 'Present'
      Name = 'DNS'
    }

    WindowsFeature InstallRSAT
    {
      Name   = 'RSAT-AD-PowerShell'
      Ensure = 'Present'
    }

    WindowsFeature InstallDNSTools
    {
      Ensure = 'Present'
      Name = 'RSAT-DNS-Server'
      DependsOn = '[WindowsFeature]InstallDNS'
    }

    WindowsFeature InstallADDSTools
    {
      Ensure = 'Present'
      Name = 'RSAT-ADDS-Tools'
      DependsOn = '[WindowsFeature]InstallADDS'
    }

    WindowsFeature ADAC {
      Name   = 'RSAT-AD-AdminCenter'
      Ensure = 'Present'
    }

    TimeZone SetTimeZone
    {
      IsSingleInstance = 'Yes'
      TimeZone         = 'W. Europe Standard Time'
    }

    ADDomainController 'ReplicaDC' {
      DomainName                 = 'test.local'
      Credential                 = $Credential
      SafeModeAdministratorPassword = $Credential
      InstallDns                 = $true            # set $false if using existing DNS
      SiteName                   = $Name  # change if needed
      DatabasePath               = 'C:\Windows\NTDS'          # optional
      LogPath                    = 'C:\Windows\NTDS'          # optional
      SysvolPath                 = 'C:\Windows\SYSVOL'        # optional
      IsGlobalCatalog            = $true
      DependsOn                  = '[WindowsFeature]InstallADDS', '[WindowsFeature]InstallDNS', '[WindowsFeature]InstallRSAT', '[WindowsFeature]InstallDNSTools', '[WindowsFeature]InstallADDSTools', '[WindowsFeature]ADAC'
    }
  }
}