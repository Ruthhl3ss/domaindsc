$script:localizedData = Get-LocalizedData -DefaultUICulture 'en-US'
