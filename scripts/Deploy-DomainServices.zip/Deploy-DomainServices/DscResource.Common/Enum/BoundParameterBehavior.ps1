enum BoundParameterBehavior
{
    All = 1
    Any
}
