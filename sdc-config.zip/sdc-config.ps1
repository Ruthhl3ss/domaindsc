<#PSScriptInfo
.Version 0.1
Score Utica SDC Domain Controller Deployment
#>

#Requires -Module ActiveDirectoryDsc
#Requires -Module ComputerManagementDsc

<#
    .DESCRIPTION
        This configuration will create a new domain with a new forest and a forest
        functional level of Server 2016.
#>
Configuration sdcdomaincontroller {

  param
  (
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [System.Management.Automation.PSCredential]
    $Credential,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $DomainName
  )

  Import-DscResource -ModuleName PSDesiredStateConfiguration
  Import-DscResource -ModuleName ActiveDirectoryDsc
  Import-DscResource -ModuleName ComputerManagementDsc

  node 'localhost'
  {

    WaitForADDomain 'WaitForestAvailability'
    {
      DomainName = $DomainName
      Credential = $Credential

      DependsOn  = '[WindowsFeature]RSATADPowerShell'
    }

    ADDomainController 'DomainControllerMinimal'
    {
      DomainName                    = $DomainName
      Credential                    = $Credential
      SafeModeAdministratorPassword = $Credential

      DependsOn                     = '[WaitForADDomain]WaitForestAvailability'
    }

  }
}