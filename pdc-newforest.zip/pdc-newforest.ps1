<#PSScriptInfo
.Version 0.1
Score Utica Domain Controller Deployment
#>

#Requires -Module ActiveDirectoryDsc
#Requires -Module ComputerManagementDsc

<#
    .DESCRIPTION
        This configuration will create a new domain with a new forest and a forest
        functional level of Server 2016.
#>
Configuration NewForest {
  param
  (
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [System.Management.Automation.PSCredential]
    $Credential,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $DomainName
  )

  Import-DscResource -ModuleName PSDesiredStateConfiguration
  Import-DscResource -ModuleName ActiveDirectoryDsc
  Import-DscResource -ModuleName ComputerManagementDsc

  node 'localhost'
  {
    WindowsFeature InstallADDS
    {
      Name   = 'AD-Domain-Services'
      Ensure = 'Present'
    }

    WindowsFeature InstallRSAT
    {
      Name   = 'RSAT-AD-PowerShell'
      Ensure = 'Present'
    }

    ADDomain CreateADForest
    {
      DomainName                    = $DomainName
      Credential                    = $Credential
      SafemodeAdministratorPassword = $Credential
      ForestMode                    = 'WinThreshold'
      DependsOn = '[WindowsFeature]InstallDNS', '[WindowsFeature]InstallADDS', '[WindowsFeature]InstallRSAT'

    }
  }
}