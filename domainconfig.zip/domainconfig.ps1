
<#PSScriptInfo
.Version 0.1
Score Utica Domain Controller Deployment
#>

#Requires -Module ActiveDirectoryDsc
#Requires -Module ComputerManagementDsc
#Requires -Module DnsServerDsc

<#
    .DESCRIPTION
        This configuration will create a new domain with a new forest and a forest
        functional level of Server 2016.
#>
Configuration domainconfig {
  param
  (
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [System.Management.Automation.PSCredential]
    $Credential,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $IPRange,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $DomainName
  )

  $Name = ($DomainName -split '\.')[0]

  Import-DscResource -ModuleName PSDesiredStateConfiguration
  Import-DscResource -ModuleName ActiveDirectoryDsc
  Import-DscResource -ModuleName ComputerManagementDsc
  Import-DscResource -ModuleName DnsServerDsc

  node 'localhost'
  {
    Script GPOCentralStore
    {
      SetScript  = {
        $DomainName = (Get-ADDomain | Select-Object DNSRoot).DNSRoot
        $PolicyDefinitions = "\\\\$DomainName\\SYSVOL\\$DomainName\\Policies"
        Copy-Item C:\Windows\PolicyDefinitions $PolicyDefinitions -Recurse -Force
      }
      GetScript  = { @{} }
      TestScript = { $false }
    }

    Script SetLocalInternetOptions
    {
      SetScript  = {
        $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0
      }
      GetScript  = { @{} }
      TestScript = { $false }
    }

    WindowsFeature ADAC {
      Name   = 'RSAT-AD-AdminCenter'
      Ensure = 'Present'
    }

    ADOptionalFeature RecycleBin
    {
      FeatureName                       = "Recycle Bin Feature"
      EnterpriseAdministratorCredential = $Credential
      ForestFQDN                        = $DomainName
    }

    DnsServerPrimaryZone 'AddPrimaryZone'
    {
      Name = "$IPRange.in-addr.arpa"
    }

    ADOrganizationalUnit 'mainou'
    {
      Name                            = $Name
      Path                            = "DC=$($Name),DC=LOCAL"
      ProtectedFromAccidentalDeletion = $true
      Ensure                          = 'Present'
    }

    ADOrganizationalUnit 'groupsou'
    {
      Name                            = 'Groups'
      Path                            = "OU=$($Name),DC=$($Name),DC=LOCAL"
      ProtectedFromAccidentalDeletion = $true
      Ensure                          = 'Present'
      DependsOn   = '[ADOrganizationalUnit]mainou'
    }

    ADOrganizationalUnit 'computersou'
    {
      Name                            = 'Computers'
      Path                            = "OU=$($Name),DC=$($Name),DC=LOCAL"
      ProtectedFromAccidentalDeletion = $true
      Ensure                          = 'Present'
      DependsOn   = '[ADOrganizationalUnit]mainou'
    }

    ADOrganizationalUnit 'usersou'
    {
      Name                            = 'Users'
      Path                            = "OU=$($Name),DC=$($Name),DC=LOCAL"
      ProtectedFromAccidentalDeletion = $true
      Ensure                          = 'Present'
      DependsOn   = '[ADOrganizationalUnit]mainou'
    }

    ADGroup 'ExampleGroup'
    {
      GroupName   = 'temp_avd_users'
      GroupScope  = 'Global'
      Category    = 'Security'
      Description = 'Temporary AVD Users Group'
      Ensure      = 'Present'
      Path        = "OU=Groups,OU=$($Name),DC=$($Name),DC=LOCAL"
      DependsOn   = '[ADOrganizationalUnit]mainou', '[ADOrganizationalUnit]groupsou'
    }

    ADGroup EmptyPreWin2000 {
      GroupName           = 'Pre-Windows 2000 Compatible Access'
      Ensure              = 'Present'
      Members             = @()                 # enforce empty
      MembershipAttribute = 'SamAccountName'    # default; explicit for clarity
      Credential          = $Credential         # domain admin or delegated
    }

    ADUser 'domainjoinuser'
    {
      Ensure     = 'Present'
      UserName   = 'su_domainjoin'
      Password   = $Credential
      DomainName = 'contoso.com'
      Path       = "OU=Users,OU=$($Name),DC=$($Name),DC=LOCAL"
      DependsOn  = '[ADOrganizationalUnit]mainou', '[ADOrganizationalUnit]usersou'
    }

    ADObjectPermissionEntry 'domainjoinpermissions'
    {
      Ensure                             = 'Present'
      Path                               = "OU=Computers,OU=$($Name),DC=$($Name),DC=LOCAL"
      IdentityReference                  = "$($Name)\su_domainjoin"
      ActiveDirectoryRights              = 'ReadProperty', 'WriteProperty'
      AccessControlType                  = 'Allow'
      ObjectType                         = '00000000-0000-0000-0000-000000000000'
      ActiveDirectorySecurityInheritance = 'Descendents'
      InheritedObjectType                = 'bf967a86-0de6-11d0-a285-00aa003049e2' # Computer objects
      DependsOn  = '[ADUser]domainjoinuser', '[ADOrganizationalUnit]computersou'
    }
  }
}
